Pixel Toran Studio editable animation collection
Canvas: 30 x 50 RGB pixels. Frames are PNG and frames.json is raw RGB source data.
The preview GIF is for review only. The AVI export is generic MJPG and has not been verified against a controller firmware, LED protocol, or LEDEdit project format.
